﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AST.Social.API.Models
{
    public class MaxMinModel
    {
        public long[] GivenArray { get; set; }
        public long Max { get; set; }
        public long Min { get; set; }
    }
}
