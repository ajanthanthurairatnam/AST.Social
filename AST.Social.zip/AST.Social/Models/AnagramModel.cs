﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AST.Social.API.Models
{
    public class AnagramModel
    {
        public string FirstWord { get; set; }
        public string SecondWord { get; set; }
        public bool isAnagram { get; set; }
    }
}
