﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AST.Social.API.Models;
using AST.Social.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace AST.Social.API.Controllers
{
    public class AssessmentController : Controller
    {
        private IArrayEvaluator _arrayEvaluator;
        private IDuplicateRemover _duplicateRemover;
        private IAnagramEvaluater _anagramEvaluater;

        public AssessmentController(IArrayEvaluator arrayEvaluator, IDuplicateRemover duplicateRemover, IAnagramEvaluater anagramEvaluater)
        {
            _arrayEvaluator = arrayEvaluator;
            _duplicateRemover = duplicateRemover;
            _anagramEvaluater = anagramEvaluater;
        }
        public IActionResult EvaluateQuestion1() => Json(new MaxMinModel()
        {
            GivenArray = _arrayEvaluator.GivenArray,
            Max = _arrayEvaluator.GetMaxValue(_arrayEvaluator.GivenArray),
            Min = _arrayEvaluator.GetMinValue(_arrayEvaluator.GivenArray)
        });

        public IActionResult EvaluateQuestion2() => Json(new DuplicateModel()
        {
            GivenString = _duplicateRemover.GivenString,
            RemoveDuplicatesGivenString1 = _duplicateRemover.RemoveDuplicatesApproach1(_duplicateRemover.GivenString),
            RemoveDuplicatesGivenString2 = _duplicateRemover.RemoveDuplicatesApproach2(_duplicateRemover.GivenString),
            RemoveDuplicatesGivenString3 = _duplicateRemover.RemoveDuplicatesApproach3(_duplicateRemover.GivenString),
            BestApproach = _duplicateRemover.BestApproach()
        });

        public IActionResult EvaluateQuestion3() => Json(new AnagramModel()
        {
            FirstWord = "school master",
            SecondWord  = "the classroom",
            isAnagram= _anagramEvaluater.AnagramChecker("school master", "the classroom")
        });

    }
}