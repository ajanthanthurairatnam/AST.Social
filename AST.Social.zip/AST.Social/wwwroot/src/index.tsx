import * as React from "react";
import * as ReactDOM from "react-dom";

import { Hello } from "./components/Hello";
import { Contact } from "./components/Contact";
import ResponsiveDrawer from "./components/ResponsiveDrawer";


export function BindDynamicComponent(component:JSX.Element,html:HTMLElement)
{
 
  return ReactDOM.render(
    <div>
      <ResponsiveDrawer />
    </div>
   ,
   html
  );
}



export {
  Hello,
  Contact,
  ResponsiveDrawer
}







