import * as React from "react";
import  QuestionProps  from "./QuestionProps";

export function Question5(props: QuestionProps)  {
    const {selectedQuestion}={...props};
   
    return (
        
        <div>
             {
             selectedQuestion ==5 &&
             <div>
           
            </div>
             }
        </div>
    );
}