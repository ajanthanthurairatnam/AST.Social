import * as React from "react";
import  QuestionProps  from "./QuestionProps";

export function Question4(props: QuestionProps)  {
    const {selectedQuestion}={...props};
   
    return (
        
        <div>
             {
             selectedQuestion == 4 &&
             <div>
            <h5>Write a RegEx to match an Australian mobile phone</h5>
            <div></div>
            </div>
             }
        </div>
    );
}