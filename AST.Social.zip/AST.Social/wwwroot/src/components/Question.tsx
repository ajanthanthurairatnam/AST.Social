import * as React from "react";
import Button from '@material-ui/core/Button';
import  QuestionProps  from "./QuestionProps";
import { Question1 } from "./Question1";
import { Question2 } from "./Question2";
import { Question3 } from "./Question3";
import { Question4 } from "./Question4";
import { Question5 } from "./Question5";

export function Question(props: QuestionProps)  {
    const {selectedQuestion}={...props};

    return (
        <div>
         <Question1 selectedQuestion={selectedQuestion} />
         <Question2 selectedQuestion={selectedQuestion} />
         <Question3 selectedQuestion={selectedQuestion} />
         <Question4 selectedQuestion={selectedQuestion} />
         <Question5 selectedQuestion={selectedQuestion} />
        </div>
    );
}