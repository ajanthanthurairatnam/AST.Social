export default interface QuestionProps {
    selectedQuestion: Number
}
