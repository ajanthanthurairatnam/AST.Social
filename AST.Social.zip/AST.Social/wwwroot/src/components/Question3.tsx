import * as React from "react";
import  QuestionProps  from "./QuestionProps";
import { useState, useEffect } from "react";

interface IAnagramModel{
    firstWord:String,
    secondWord:String,
    isAnagram:boolean 
}

export function Question3(props: QuestionProps)  {
    const {selectedQuestion}={...props};
   
    const [anagramModel, setAnagramModel] = useState<IAnagramModel>(null);
   
    useEffect(() => {
        // Update the document title using the browser API
        getAnswer();
      },[selectedQuestion]);


    const getAnswer=()=>{
        $.getJSON( "/Assessment/EvaluateQuestion3", function(model:IAnagramModel) {
            setAnagramModel(model)
          });
    }

    return (
        <div>
             {
             selectedQuestion == 3 &&
             <div>
               <h5>Write a function that checks if two strings are Anagram</h5>
               <div>
                    {
                        anagramModel!=null && 
                        <div>
                            <div>First Word: {anagramModel.firstWord} </div>
                            <div>Second Word: {anagramModel.secondWord}</div>
                            <div>Is Anagram: {String(anagramModel.isAnagram)}</div>
                        </div>
                    }
                </div>
            </div>
             }
        </div>
    );

}