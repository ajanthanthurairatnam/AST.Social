import * as React from "react";
import  QuestionProps  from "./QuestionProps";
import { useState, useEffect } from "react";


interface IDuplicateModel{
    givenString:string,
    removeDuplicatesGivenString1:string,
    removeDuplicatesGivenString2:string,
    removeDuplicatesGivenString3:string,
    bestApproach:string
}   

export function Question2(props: QuestionProps)  {
    const {selectedQuestion}={...props};
    const [duplicateModel, setDuplicateModel] = useState<IDuplicateModel>(null);
  
    useEffect(() => {
        // Update the document title using the browser API
        getAnswer();
      },[selectedQuestion]);


    const getAnswer=()=>{
        $.getJSON( "/Assessment/EvaluateQuestion2", function(model:IDuplicateModel) {
            setDuplicateModel(model)
          });
    }


    return (
        
        <div>
             {
             selectedQuestion == 2 &&
             <div>
            <h5>Write a function that removes duplicate characters from string. Provide at least 3 solutions. Which is best in your opinion? Why?</h5>
            <div>
            {
                        duplicateModel!=null && 
                        <div>
                            <div>Given String: {duplicateModel.givenString} </div>
                            <div>Remove Duplicates From GivenString 1:  {duplicateModel.removeDuplicatesGivenString1}</div>
                            <div>Remove Duplicates From GivenString 2:  {duplicateModel.removeDuplicatesGivenString2}</div>
                            <div>Remove Duplicates From GivenString 3:  {duplicateModel.removeDuplicatesGivenString3}</div>
                            <div>Best Approach:  {duplicateModel.bestApproach}</div>
                         
                        </div>
            }
            </div>
            </div>
             }
        </div>
    );
}