import * as React from "react";
import  QuestionProps  from "./QuestionProps";
import { useEffect, useState } from "react";

interface IMaxMinModel{
    givenArray:Number[],
    max:Number,
    min:Number
}

export function Question1(props: QuestionProps)  {
    const {selectedQuestion}={...props};
    const [maxMinModel, setMaxMin] = useState<IMaxMinModel>(null);
   
    useEffect(() => {
        // Update the document title using the browser API
        getAnswer();
      },[selectedQuestion]);


    const getAnswer=()=>{
        $.getJSON( "/Assessment/EvaluateQuestion1", function(model:IMaxMinModel) {
            setMaxMin(model)
          });
    }

    return (
        <div>
             {
             selectedQuestion == 1 &&
             <div>
                <h5>Write a function that finds the largest and smallest numbers in an array</h5>
                <div>
                    {
                        maxMinModel!=null && 
                        <div>
                            <div>Given Array: {maxMinModel.givenArray.join(",")} </div>
                            <div>Max: {maxMinModel.max}</div>
                            <div>Min: {maxMinModel.min}</div>
                        </div>
                    }
                </div>
            </div>
             }
        </div>
    );
}