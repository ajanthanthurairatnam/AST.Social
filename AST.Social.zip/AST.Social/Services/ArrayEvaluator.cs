﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AST.Social.API.Services
{
    public interface IArrayEvaluator
    {
        long[] GivenArray { get; set; }
        long GetMaxValue(long[] GivenArray);
        long GetMinValue(long[] GivenArray);
    }
    public class ArrayEvaluator : IArrayEvaluator
    {
        public long GetMaxValue(long[] GivenArray)
        {
            return GivenArray.Max();
        }

        public long GetMinValue(long[] GivenArray)
        {
            return GivenArray.Min();
        }

        public long[] GivenArray { get; set; } = new long[] { 2, 3, 4, 5, 6, 7, 8, 9, 11 };

    }
}
