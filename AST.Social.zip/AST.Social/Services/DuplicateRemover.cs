﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace AST.Social.API.Services
{
    public interface IDuplicateRemover
    {
        public string GivenString { get; set; }

        public string RemoveDuplicatesApproach1(string input);

        public string RemoveDuplicatesApproach2(string input);

        public string RemoveDuplicatesApproach3(string input);

        public string BestApproach();

    }
    public class DuplicateRemover: IDuplicateRemover
    {
        private IArrayEvaluator _arrayEvaluator;
        public DuplicateRemover(IArrayEvaluator arrayEvaluator)
        {
            _arrayEvaluator = arrayEvaluator;
        }
        public string GivenString { get; set; } = "There are many variations of passages " +
            "of Lorem Ipsum available, but the majority have suffered alteration in some form, " +
            "by injected humour, or randomised words which don't look even slightly believable. " +
            "If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't " +
            "anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators " +
            "on the Internet tend to repeat predefined chunks as necessary, making this the first " +
            "true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with " +
            "a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. " +
            "The generated Lorem Ipsum is therefore always free from repetition, injected humour, " +
            "or non-characteristic words etc.";

        public string BestApproach()
        {


            Stopwatch sw = new Stopwatch();
            sw.Start();
            RemoveDuplicatesApproach1(GivenString);
            sw.Stop();
            long elapsedticksApproach1 = sw.ElapsedTicks;
            
            sw.Reset();
            sw.Restart();
            RemoveDuplicatesApproach2(GivenString);
            sw.Stop();
            long elapsedticksApproach2 = sw.ElapsedTicks;
            
            sw.Reset();
            sw.Restart();
            RemoveDuplicatesApproach3(GivenString);
            sw.Stop();
            long elapsedticksApproach3= sw.ElapsedTicks;
            sw.Reset();
            
            var elapsed = new long[] { elapsedticksApproach1, elapsedticksApproach2, elapsedticksApproach3 };

            var minValue=_arrayEvaluator.GetMinValue(elapsed);
            int bestApproachNo= Array.IndexOf(elapsed, minValue)+1;

            return $"Best Approach : Approach{bestApproachNo.ToString()} Elapsed Ticks : {minValue.ToString()}";

        }

        public string RemoveDuplicatesApproach1(string input)
        {
            return new string(input.Distinct().ToArray());
        }

        public string RemoveDuplicatesApproach2(string input)
        {
            string newString = string.Empty;
            List<char> found = new List<char>();
            foreach (char c in input)
            {
                if (found.Contains(c))
                    continue;

                newString += c.ToString();
                found.Add(c);
            }
            return newString;
        }

        public string RemoveDuplicatesApproach3(string input)
        {
            var output = string.Join("", input.ToHashSet());
            return output;
        }

    }
}
